document.getElementById('file').innerHTML = "hello world from js";
document.getElementById('file').style.backgroundColor = 'blue';